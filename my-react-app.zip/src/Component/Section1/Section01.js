import React from "react";
import ReactDom from "react-dom";
import { BrowserRouter as Router , NavLink } from "react-router-dom";
import "./Section01.css";
import house from "./home-icon.png";
import rac from "./track-order.png";
import aim from "./download.png";
import edo from "./download1.png";
import anno from "./annous(2).png";
import conf from "./conference.png";
import abo from "./abou-us.png";

function Section01() {
  return (
    <>
      <div className="Section01-area">
        <div className=" inner-Section01 container">
          <div className="Section01">
            <div className=" links jc-cen">
              <span>IJASR</span>
            </div>
            <NavLink exact  to="/" className=" Linkkk" >
              <div className="links">
                <span className="line"><img src={house} alt="heading" /></span>
                Home
              </div>
            </NavLink>

            <NavLink exact to="/track-article" className=" Linkkk">
              <div className="links"> 
                <span className="line"><img src={rac} alt="heading" /></span>
                Track Article
              </div>
            </NavLink>

            <NavLink exact to="/aim-and-scope" className=" Linkkk">
              <div className="links">
                <span className="line"><img src={aim} alt="heading" /></span>
                Aim and scope
              </div>
            </NavLink>
            <NavLink exact to="/editorial-committee" className=" Linkkk">
              <div className="links ">   
                <span className="line"><img src={edo} alt="heading" /></span>
                Editorial Committee
              </div>
            </NavLink>

            <NavLink exact to="/latest-announcement" className=" Linkkk">
              <div className="links">    
                <span className="line"><img src={anno} alt="heading" /></span>
                Latest Announcement
              </div>
            </NavLink>

            <NavLink exact to="/conference-support" className=" Linkkk">
              <div className="links"> 
                <span className="line"><img src={conf} alt="heading" /></span>
                Conference Support
              </div>
            </NavLink>

            <NavLink exact to="/about" className=" Linkkk">
              <div className="links border-bottomm">
                <span className="line"><img src={abo} alt="heading" /></span>
                About us
              </div>
            </NavLink>
          </div>
          <div className="Section01 mt-3">
            <div className=" links jc-cen">
              <span>Archive</span>
            </div>
            <NavLink exact to="/current-issue" className=" Linkkk">
              <div className="links">
                <span className="line"><img src={house} alt="heading" /></span>
                Current Issue
              </div>
            </NavLink>

            <NavLink exact to="/past-issue" className=" Linkkk">
              <div className="links">
                <span className="line"><img src={rac} alt="heading" /></span>
                Past Issue
              </div>
            </NavLink>
            </div>
            
            <div className="Section01 mt-3">
            <div className="heading links jc-cen">
              <span>For Authors</span>
            </div>
            <NavLink exact to="/instruction-for-authors" className=" Linkkk">
              <div className="links">
                <span className="line"><img src={house} alt="heading" /></span>
                Instruction For Authors
              </div>
            </NavLink>

            <NavLink exact to="/manuscript-template" className=" Linkkk">
              <div className="links">
                <span className="line"><img src={house} alt="heading" /></span>
                Manuscript Template
              </div>
            </NavLink>

            <NavLink exact to="/publication-charges" className=" Linkkk">
              <div className="links">
                <span className="line"><img src={house} alt="heading" /></span>
                Publication Charges
              </div>
            </NavLink>

            <NavLink exact to="/Copyright-form" className=" Linkkk">
              <div className="links">
                <span className="line"><img src={house} alt="heading" /></span>
                Copyright Form
              </div>
            </NavLink>

            <NavLink exact to="/online-paper-submission" className=" Linkkk">
              <div className="links">
              <span className="line"><img src={rac} alt="heading" /></span>
              Online Paper Submission
              </div>
            </NavLink>
            </div>

            <div className="Section01 mt-3">
            <div className="links jc-cen">
              <span>Others</span>
            </div>
            <NavLink exact to="/indexing-services" className=" Linkkk">
              <div className="links">
              <span className="line"><img src={house} alt="heading" /></span>
              Indexing Services
              </div>
            </NavLink>

            <NavLink exact to="/open-access" className=" Linkkk">
              <div className="links">
              <span className="line"><img src={house} alt="heading" /></span>
              Open Access              
              </div>
            </NavLink>
            </div>

        </div>
      </div>
    </>
  );
}
export default Section01;
