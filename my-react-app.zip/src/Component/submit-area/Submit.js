import React from "react";
import ReactDom from "react-dom";
import "./Submit.css";

function Submit() {
    return(
  <>
    <div className="submit-area">
      <div className=" inner-submit container">
        <div className="web-name">
        <span>International Journal of Advanced Technology & Science Research</span>
        </div>
        <div className="submit-btn">
            <button>SUBMIT PAPER</button>
        </div>
      </div>
    </div>
  </>
    )
}
export default Submit;
