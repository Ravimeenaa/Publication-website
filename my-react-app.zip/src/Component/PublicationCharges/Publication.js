import React from "react";
import ReactDom from "react-router-dom";
import { BrowserRouter as Router, NavLink } from "react-router-dom";
import "./Publication.css";
import "../Homes/home.css";

function Publication() {
  return (
    <>
      <div className="home-maindiv Instruction-main-div">
        <div className="heading">
          <h5>Publication Charges</h5>
        </div>
        <p>
          <b>
            International Journal of Advanced Technology and Science Research
            (IJATSR)
          </b>
          is an initiative to provide quality publishing platform for research
          scholars. All the papers are published after successful peer review by
          qualified researchers.
        </p>
        <p>
          All articles published in our journal are open access and freely
          available online, immediately upon publication. This is made possible
          by an article-processing charge (APC) that covers the range of
          publishing services we provide. This includes provision of online
          tools for editors and authors, article production and hosting, liaison
          with abstracting and indexing services, and customer services. The
          APC, payable when your manuscript is editorially accepted and before
          publication, is charged to either you, or your funder, institution or
          employer.
        </p>

        <p>
          <b>Publishing charges for online publication:</b>
        </p>

        <p>DUE TO COVID-19, WE ARE PUBLISHING WITH 50% DISCOUNT.</p>
        <p>
          This charges applicable up to 30 pages, above 30 pages Authors will be
          charged $ 5 USD per page.
        </p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
      </div>
    </>
  );
}
export default Publication;
