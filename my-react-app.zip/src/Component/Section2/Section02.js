import React from "react";
import ReactDom from "react-dom";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Home from "../Homes/Home";
import About from "../Abouts/About";
import Contact from "../Contacts/Contact";
import Aim from "../Aim and Scope/Aim";
import Editorial from "../Editorial Committee/Editorial";
import "./Section02.css";
import Instruction from '../Instruction For Authors/Instruction'
import ConferenceSupport from "../Conference-Support/ConferenceSupport";
import Publication from "../PublicationCharges/Publication"


function Section02() {
  return (
    <>
      <div className="Section02-area ">
        <div className=" inner-Section02 container">
          <div className="Section02">
            <Route exact path="/" component={Home} />
            <Route path="/about" component={About} />
            <Route path="/contact" component={Contact} />
            <Route path="/aim-and-scope" component={Aim} />
            <Route path="/editorial-committee" component={Editorial} />
            <Route path="/conference-support" component={ConferenceSupport} />
            <Route path="/instruction-for-authors" component={Instruction} />
            <Route path="/publication-charges" component={Publication} />


          </div>
        </div>
      </div>
    </>
  );
}
export default Section02;
