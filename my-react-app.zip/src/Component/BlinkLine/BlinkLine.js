import React from "react";
import ReactDom from "react-dom";
import "./BlinkLine.css";

function BlinkLine() {
    return(
  <>
    <div className="BlinkLine-area">
      <div className=" inner-BlinkLine container">
        <div className="Blink">
        <span>Due to Covid-19, we are publishing with 50% discount.</span>
        </div>
      </div>
    </div>
  </>
    )
}
export default BlinkLine;
