import React from "react";
import ReactDom from "react-dom";
import { BrowserRouter as Router, Link } from "react-router-dom";
import "../Section1/Section01.css";
import faq from "./faq.png";
import pablication from "./publi-es.png";

function Section03() {
  return (
    <>
      <Router>
        <div className="Section01-area">
          <div className=" inner-Section01 container">
            <div className="Section01">
              <div className="heading links jc-cen">
                <span>IJASR</span>
              </div>
              <Link to="/frequently-asked-questions" className=" Linkkk">
                <div className="links">
                  <span className="line">
                    <img src={faq} alt="heading" />
                  </span>
                  FAQ
                </div>
              </Link>

              <Link exact to="/publication-ethic-statement" className=" Linkkk">
                <div className="links">
                  <span className="line">
                    <img src={pablication} alt="heading" />
                  </span>
                  Publication Ethic Statement
                </div>
              </Link>

              <Link exact to="/contact-for-help" className=" Linkkk">
                <div className="links">
                  <span className="line">
                    <img src={faq} alt="heading" />
                  </span>
                  Contact for Help
                </div>
              </Link>

              <Link exact to="/message-by-editor" className=" Linkkk">
                <div className="links ">
                  <span className="line">
                    <img src={faq} alt="heading" />
                  </span>
                  Message by Editor
                </div>
              </Link>

              <Link
                exact
                to="/call-for-editorial-board-members"
                className=" Linkkk"
              >
                <div className="links border-bottomm">
                  <span className="line">
                    <img src={faq} alt="heading " />
                  </span>
                  Call for Editorial Board Members
                </div>
              </Link>
            </div>

            <div className="Section01">
              <div className=" links jc-cen">
                <span>Call for Paper</span>
              </div>

              <div className="links">
                <p className="line ">
                  International Journal of Advanced Technology and Science
                  Research Inviting Papers/Articles for Current Issue Volume 2
                  Issue 6 June 2021. Submit your Paper through Online Submission
                  System. Authors also can Send Paper to submit@ijatsr.org
                </p>
              </div>
            </div>
          </div>
        </div>
      </Router>
    </>
  );
}
export default Section03;
