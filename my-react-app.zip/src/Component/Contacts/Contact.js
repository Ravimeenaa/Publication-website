import React from "react";
import ReactDom from 'react-router-dom'


const Contact = () => {
  return (
    <>
      <h1>i am  Contect page</h1>
    </>
  );
};
export default Contact;
